package br.com.cesarschool.poo.titulos.utils;

public interface Comparador {
    int comparar(Comparavel c1, Comparavel c2);
}
