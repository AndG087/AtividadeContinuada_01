package br.com.cesarschool.poo.titulos.utils;


public abstract class ComparadorPadrao implements Comparador {
    @Override
    public int comparar(Comparavel c1, Comparavel c2) {
       
        return 0; 
    }
}