package br.com.cesarschool.poo.titulos.utils;

public interface Comparavel {
    int comparar(Comparavel c);
}